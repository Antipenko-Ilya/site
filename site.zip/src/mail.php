<?php

$data = $_POST;

echo $data[username];
// echo json_encode($data,JSON_UNESCAPED_UNICODE);
?>